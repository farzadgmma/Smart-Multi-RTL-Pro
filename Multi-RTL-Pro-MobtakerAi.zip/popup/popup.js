document.addEventListener('DOMContentLoaded', async () => {
    const globalToggle = document.getElementById('global-toggle');
    const domainToggle = document.getElementById('domain-toggle');
    const currentDomainEl = document.getElementById('current-domain');
    const modeSelect = document.getElementById('mode-select');
    const fontSelect = document.getElementById('font-select');
    const sizeSelect = document.getElementById('size-select');
    const lineheightSelect = document.getElementById('lineheight-select');
    const numbersToggle = document.getElementById('numbers-toggle');
    const widgetToggle = document.getElementById('widget-toggle');
    const translatePageBtn = document.getElementById('translatePageBtn');
    const toggleCurrentBtn = document.getElementById('toggleCurrentBtn');
    const statusMsg = document.getElementById('status-msg');

    let currentDomain = '';

    const getActiveTab = (cb) =>
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => tabs[0] && cb(tabs[0]));

    // Tab Navigation switching
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach((btn) => {
        btn.addEventListener('click', () => {
            tabBtns.forEach((b) => b.classList.remove('active'));
            tabContents.forEach((c) => c.classList.remove('active'));

            btn.classList.add('active');
            const targetTab = document.getElementById(btn.getAttribute('data-tab'));
            if (targetTab) targetTab.classList.add('active');
        });
    });

    // Handle external links safely in extension popup
    document.querySelectorAll('a[href^="http"]').forEach((link) => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const href = link.getAttribute('href');
            if (href) {
                chrome.tabs.create({ url: href });
            }
        });
    });

    // Get current tab domain
    getActiveTab((tab) => {
        if (tab && tab.url && tab.url.startsWith('http')) {
            try {
                const urlObj = new URL(tab.url);
                currentDomain = urlObj.hostname;
                currentDomainEl.textContent = currentDomain;
            } catch (e) {
                currentDomainEl.textContent = 'صفحه وب';
            }
        } else {
            currentDomainEl.textContent = 'صفحه مرورگر';
            domainToggle.disabled = true;
        }
    });

    // Load initial settings
    chrome.storage.sync.get({
        enabled: true,
        font: 'vazir',
        mode: 'auto',
        fontSize: '100',
        lineHeight: 'normal',
        convertNumbers: false,
        showWidget: false,
        disabledSites: []
    }, (stored) => {
        globalToggle.checked = stored.enabled;
        modeSelect.value = stored.mode || 'auto';
        fontSelect.value = stored.font || 'vazir';
        sizeSelect.value = stored.fontSize || '100';
        lineheightSelect.value = stored.lineHeight || 'normal';
        numbersToggle.checked = !!stored.convertNumbers;
        widgetToggle.checked = !!stored.showWidget;

        if (currentDomain) {
            const isDisabled = Array.isArray(stored.disabledSites) && stored.disabledSites.includes(currentDomain);
            domainToggle.checked = !isDisabled;
        }
    });

    function saveSettings() {
        chrome.storage.sync.get({ disabledSites: [] }, (stored) => {
            let disabledSites = stored.disabledSites || [];

            if (currentDomain) {
                if (!domainToggle.checked) {
                    if (!disabledSites.includes(currentDomain)) {
                        disabledSites.push(currentDomain);
                    }
                } else {
                    disabledSites = disabledSites.filter(d => d !== currentDomain);
                }
            }

            const newSettings = {
                enabled: globalToggle.checked,
                font: fontSelect.value,
                mode: modeSelect.value,
                fontSize: sizeSelect.value,
                lineHeight: lineheightSelect.value,
                convertNumbers: numbersToggle.checked,
                showWidget: widgetToggle.checked,
                disabledSites: disabledSites
            };

            chrome.storage.sync.set(newSettings, () => {
                showStatusMessage();
                notifyContentScript();
            });
        });
    }

    function notifyContentScript() {
        getActiveTab((tab) => {
            chrome.tabs.sendMessage(tab.id, { action: 'SETTINGS_UPDATED' }).catch(() => {});
        });
    }

    function showStatusMessage() {
        if (!statusMsg) return;
        statusMsg.classList.add('show');
        setTimeout(() => {
            statusMsg.classList.remove('show');
        }, 1200);
    }

    // Full Page Translate Button Handler
    if (translatePageBtn) {
        translatePageBtn.addEventListener('click', () => {
            getActiveTab((tab) => {
                chrome.tabs.sendMessage(tab.id, { action: 'TRANSLATE_PAGE_FA' }).catch(() => {});
            });
        });
    }

    // Toggle current element direction button
    if (toggleCurrentBtn) {
        toggleCurrentBtn.addEventListener('click', () => {
            getActiveTab((tab) => {
                chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_CURRENT_ELEMENT_RTL' }).catch(() => {});
            });
        });
    }

    // Event Listeners
    globalToggle.addEventListener('change', saveSettings);
    domainToggle.addEventListener('change', saveSettings);
    modeSelect.addEventListener('change', saveSettings);
    fontSelect.addEventListener('change', saveSettings);
    sizeSelect.addEventListener('change', saveSettings);
    lineheightSelect.addEventListener('change', saveSettings);
    numbersToggle.addEventListener('change', saveSettings);
    widgetToggle.addEventListener('change', saveSettings);
});
